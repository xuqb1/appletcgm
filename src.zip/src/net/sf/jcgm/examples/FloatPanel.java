package net.sf.jcgm.examples;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

public class FloatPanel extends JPanel{
	List<Comment> comments=new ArrayList<Comment>();
	FontMetrics fm;
	Font font;
	int selectedIndex=-1;
	int imgWidth=20;
	int imgHeight=20;
	FloatPanel(){
		this.font = new Font(null, Font.PLAIN, 12);
		this.fm=this.getFontMetrics(font);
	}
	FloatPanel(List<Comment> comments){
		this.comments=comments;
	}
	public void setImgWidth(int w) {
		this.imgWidth=w;
	}
	public void setImgHeight(int h) {
		this.imgHeight=h;
	}
	@Override
	public void paint(Graphics g) {
		if(comments==null || comments.size()<=0) {
			return;
		}
		g.setColor(Color.RED);
		for(int i=0;i<comments.size();i++) {
			int commX=comments.get(i).getX();
			int commY=comments.get(i).getY();
			int x=this.getSize().width;//comments.get(i).getCurH();
			int y=this.getSize().height;//comments.get(i).getCurW();
			//int startX=this.getX();
			//int startY=this.getY();
			
			//int imgWidth=comments.get(i).getPicH();
			//int imgHeight=comments.get(i).getPicW();
			
			//double scale=(double)(imgWidth/imgHeight);
			//int posX=commX*x/imgWidth;
			//int posY=(int)(commY*y/(imgWidth*scale));
			
			int posX=commX*x/imgWidth;//+startX;
			int posY=commY*y/imgHeight;//+startY;
			
			//System.out.println("commX,CommY="+commX+","+commY);
			//System.out.println("x,y="+x+","+y);
			//System.out.println("imgWidth,imgHeight="+imgWidth+","+imgHeight);
			//System.out.println("posX,posY="+posX+","+posY);
			g.setFont(font);
			//g.drawString(comments.get(i).getComment(), posX+5, posY+25);
			
			g.drawString(comments.get(i).getComment(), posX+5, posY);
			
			int txtWidth=fm.stringWidth(comments.get(i).getComment());
			Rectangle2D txtRect=fm.getStringBounds(comments.get(i).getComment(), g);
			//g.drawRect(posX, posY, (int)txtRect.getWidth(), (int)txtRect.getHeight());
			g.drawRect(posX, posY-12, txtWidth+10, 14);
			
			if(i==selectedIndex) {
				g.setColor(Color.BLUE);
				g.drawString(comments.get(i).getComment(), posX+5, posY);//+25);
				g.drawRect(posX, posY-12, txtWidth+10, 14);
				g.setColor(Color.RED);
			}
			comments.get(i).setCurH(14);
			comments.get(i).setCurW(txtWidth+10);
			comments.get(i).setCurX(posX);
			comments.get(i).setCurY(posY-9);//+14);
		}
	}
	public int getSelectedIndex() {
		return selectedIndex;
	}
	public void setSelectedIndex(int selectedIndex) {
		this.selectedIndex = selectedIndex;
	}
	public List<Comment> getComments() {
		return comments;
	}
	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}
}
