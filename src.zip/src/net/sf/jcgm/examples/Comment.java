package net.sf.jcgm.examples;

import java.awt.Point;

public class Comment {
	int x;
	int y;
	int picW,picH;
	int curW,curH;
	int curX,curY;
	String comment;
	public int getX() {
		return x;
	}
	public int getCurX() {
		return curX;
	}
	public void setCurX(int curX) {
		this.curX = curX;
	}
	public int getCurY() {
		return curY;
	}
	public void setCurY(int curY) {
		this.curY = curY;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public void setPos(int x,int y) {
		this.x=x;
		this.y=y;
	}
	public Point getPos() {
		return new Point(x,y);
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getPicW() {
		return picW;
	}
	public void setPicW(int picW) {
		this.picW = picW;
	}
	public int getPicH() {
		return picH;
	}
	public void setPicH(int picH) {
		this.picH = picH;
	}
	public int getCurW() {
		return curW;
	}
	public void setCurW(int curW) {
		this.curW = curW;
	}
	public int getCurH() {
		return curH;
	}
	public void setCurH(int curH) {
		this.curH = curH;
	}
	
}
