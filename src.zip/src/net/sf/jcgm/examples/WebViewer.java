package net.sf.jcgm.examples;

import java.applet.Applet;
import java.applet.AppletContext;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.PrivilegedAction;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import javax.swing.JCheckBox;

import net.sf.jcgm.core.CGMPanel;

/**
 * Program to view CGM files and compare them to reference files.
 * @version $Id: Viewer.java 22 2010-02-04 16:49:09Z phica $
 * @author Philippe Cadé
 * @since Oct 15, 2009
 */
public class WebViewer extends Applet implements PrivilegedAction<Object>{
	private static final long serialVersionUID = 1L;
	
	JPanel topPanel;
	JPanel scrollpanel;
	JButton showAllbtn,showWidthbtn,show1v1btn,showSelbtn,showZoomOutbtn;
	JButton showZoomInbtn,panbtn,showHotbtn;
	JCheckBox showhideCommentbtn;
	private CGMPanel cgmLabel;
	private String imageParam="";
	String errorStr="";
	URL cgmFileUrl=null;
	String imageUrl="";
	
	
	int x,y;                      //ͼƬʵʱ����
	int startX, startY;           //ͼƬ���Ͻ�λ��
	double scale;                  //ͼƬ���ݱ� x/y
	int imgWidth=20;              //ͼƬԭʼ����
	int imgHeight=20;				//ͼƬԭʼ�߶�
	private AppletContext context;
  
	boolean boundZoom =false;
	int boundX=0;
	int boundY=0;
	int boundWidth=0;
	int boundHeight=0;
  
	boolean inPic = false;        //����Ƿ���ͼƬ��
	int begin_x, begin_y;         //�϶�ʱ����ʼ��
	JPopupMenu popupMenu;         //�����˵�
	JMenuItem menuItem;           //���ӱ�ע�˵���
	JMenuItem showHideComment;    //��ʾ���ر�ע�˵���
	JMenuItem deleteCommentMenu;	  //ɾ����ע�˵���
	boolean showComment=false;    //�Ƿ���ʾ��ע��ʶ
  	List<Comment> comments=new ArrayList<Comment>();
  	int commentX,commentY;			//���������ͼ��ԭʼ�ߴ磬��ע���ڵ�λ��
  	Graphics floatpanelG;
  	String getAnnotatePage="getAnnotate.jsp";//?imgfile=xxx.cgm
	String setAnnotatePage="setAnnotate.jsp";//?imgfile=xxx.cgm
	int selectedAnnIndex=-1;	//ѡ�еı�ע������
  	
  	FloatPanel floatPanel;
	public void init() {
		buildUI();
		this.showAllbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				if(e.getButton()!=MouseEvent.BUTTON1) {
					return;
				}
				double scrollpanelScale=(double)scrollpanel.getSize().width/scrollpanel.getSize().height;
				if(scrollpanelScale==scale) {
					startX=0;
					startY=0;
					x=scrollpanel.getSize().width;
					y=scrollpanel.getSize().height;
				}else if(scrollpanelScale>scale){//��ƽ�ģ����ȸ߶�
					y=scrollpanel.getSize().height;
					x=(int)(y*scale);
					startY=0;
					startX=(scrollpanel.getSize().width-x)/2;
				}else {//�߿��ģ����ȿ���
					x=scrollpanel.getSize().width;
					y=(int)(x/scale);
					startX=0;
					startY=(scrollpanel.getSize().height-y)/2;
				}
				cgmLabel.setLocation(startX,startY);
				cgmLabel.setSize(x,y);
				floatPanel.setLocation(startX,startY);
				floatPanel.setSize(x,y);
				//floatPanel.repaint();
				scrollpanel.repaint();
			}
		});
		this.showWidthbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				if(e.getButton()!=MouseEvent.BUTTON1) {
					return;
				}
				x=scrollpanel.getSize().width;
				y=(int)(x/scale);
				startX=0;
				startY=0;
				if(y<scrollpanel.getSize().height) {
					startY=(scrollpanel.getSize().height-y)/2;
				}
				cgmLabel.setLocation(startX,startY);
				cgmLabel.setSize(x,y);
				floatPanel.setLocation(startX,startY);
				floatPanel.setSize(x,y);
				scrollpanel.repaint();
			}
		});
		this.show1v1btn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				if(e.getButton()!=MouseEvent.BUTTON1) {
					return;
				}
				startX=0;
				startY=0;
				x=imgWidth;
				y=(int)(x/scale);
				if(x<scrollpanel.getSize().width) {
					startX=(scrollpanel.getSize().width-x)/2;
				}
				if(y<scrollpanel.getSize().height) {
					startY=(scrollpanel.getSize().height-y)/2;
				}
				cgmLabel.setLocation(startX,startY);
				cgmLabel.setSize(x,y);
				floatPanel.setLocation(startX,startY);
				floatPanel.setSize(x,y);
				scrollpanel.repaint();
			}
		});
		this.showSelbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				if(e.getButton()!=MouseEvent.BUTTON1) {
					return;
				}
				boundZoom=true;
			}
		});
		this.showZoomOutbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				if(e.getButton()!=MouseEvent.BUTTON1) {
					return;
				}
				int tmpX, tmpY, maxX, maxY;
				int zoomStep=10;
				int mx,my;
				String tmpStr=getParameter("zoomstep");
				if(tmpStr!=null && "".equals(tmpStr.trim())) {
					zoomStep=Integer.valueOf(tmpStr);
				}
	        	tmpX=startX;
	        	tmpY=startY;
	        	if(startX<0){
	        		tmpX=0;
	        	}
	        	if(startY<0){
	        		tmpY=0;
	        	}
	        	maxX=tmpX+x;
	        	maxY=tmpY+y;
	        	mx=(int)(scrollpanel.getSize().width/2);
	        	my=(int)(scrollpanel.getSize().height/2);
	        	//if(inPicBounds(e.getX(),e.getY())){
	        		
        		double xpos, ypos;
        	    //mx=e.getX();
        	    //my=e.getY();
        	    xpos=(double)(mx-startX)/x;
        	    ypos=(double)(my-startY)/y;
        	    int direct=1;//�Ŵ�
        	    //if(e.getWheelRotation()==-1){
        	    //  direct=1;
        	    //}
        	    x=x+zoomStep*direct;
        	    y=y+(int)(zoomStep/scale*direct);
        	    //startX -= 5*direct;
        	    //startY -= (int)(5/scale*direct);
        	    startX = mx-(int)(x*xpos);
        	    startY = my-(int)(y*ypos);
        	    if(scale>1) {
        	    	if(x<100) {
        	    		//x=100;
        	    		//y=(int)(x/scale);
        	    		return;
        	    	}
        	    }else {
        	    	if(y<100) {
        	    		//y=100;
        	    		//x=(int)(y*scale);
        	    		return;
        	    	}
        	    }
        	    cgmLabel.setLocation(startX, startY);
        	    cgmLabel.setSize(x,y);
        	    floatPanel.setLocation(startX,startY);
				floatPanel.setSize(x,y);
        	    scrollpanel.repaint();
			}
		});
		this.showZoomInbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				if(e.getButton()!=MouseEvent.BUTTON1) {
					return;
				}
				int tmpX, tmpY, maxX, maxY;
				int zoomStep=10;
				int mx,my;
				String tmpStr=getParameter("zoomstep");
				if(tmpStr!=null && "".equals(tmpStr.trim())) {
					zoomStep=Integer.valueOf(tmpStr);
				}
	        	tmpX=startX;
	        	tmpY=startY;
	        	if(startX<0){
	        		tmpX=0;
	        	}
	        	if(startY<0){
	        		tmpY=0;
	        	}
	        	maxX=tmpX+x;
	        	maxY=tmpY+y;
	        	mx=(int)(scrollpanel.getSize().width/2);
	        	my=(int)(scrollpanel.getSize().height/2);
	        	//if(inPicBounds(e.getX(),e.getY())){
	        		
        		double xpos, ypos;
        	    //mx=e.getX();
        	    //my=e.getY();
        	    xpos=(double)(mx-startX)/x;
        	    ypos=(double)(my-startY)/y;
        	    int direct=-1;//��С
        	    //if(e.getWheelRotation()==-1){
        	    //  direct=1;
        	    //}
        	    x=x+zoomStep*direct;
        	    y=y+(int)(zoomStep/scale*direct);
        	    //startX -= 5*direct;
        	    //startY -= (int)(5/scale*direct);
        	    startX = mx-(int)(x*xpos);
        	    startY = my-(int)(y*ypos);
        	    if(scale>1) {
        	    	if(x<100) {
        	    		//x=100;
        	    		//y=(int)(x/scale);
        	    		return;
        	    	}
        	    }else {
        	    	if(y<100) {
        	    		//y=100;
        	    		//x=(int)(y*scale);
        	    		return;
        	    	}
        	    }
        	    cgmLabel.setLocation(startX, startY);
        	    cgmLabel.setSize(x,y);
        	    floatPanel.setLocation(startX,startY);
				floatPanel.setSize(x,y);
        	    scrollpanel.repaint();
			}
		});
		this.panbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				if(e.getButton()!=MouseEvent.BUTTON1) {
					return;
				}
				boundZoom=false;
			}
		});
		/*
		this.showHotbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				if(e.getButton()!=MouseEvent.BUTTON1) {
					return;
				}
				boundZoom=false;
			}
		});
		*/
		this.showhideCommentbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				showComment=showhideCommentbtn.isSelected();
				if(!showComment) {
					saveComments();
				}else {
					getComments();
					cgmLabel.setLocation(startX, startY);
					floatPanel.setLocation(startX,startY);
					floatPanel.setSize(x,y);
				}
				repaint();
			}
		});
		/*
		this.cgmLabel.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {  //��갴ť�����¼���Ӧ��������£�ȷ���Ƿ���϶����Ҽ������˵�
				//int mods=e.getModifiers();
				//if ((mods & InputEvent.BUTTON3_MASK) != 0) {//�Ҽ�
	        	if(e.getButton() == MouseEvent.BUTTON3) {//�Ҽ�����
					popupMenu.show(e.getComponent(), e.getX(), e.getY());
					popupMenu.show();
					currComment.setPos(e.getX()*imgWidth/x, e.getY()*imgHeight/y);
					System.out.println("�Ҽ�����e.x,e.y="+e.getX()+","+e.getY());
					return;
				}
			}
		});*/
		this.scrollpanel.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {  //��갴ť�����¼���Ӧ��������£�ȷ���Ƿ���϶����Ҽ������˵�
				//int mods=e.getModifiers();
				//if ((mods & InputEvent.BUTTON3_MASK) != 0) {//�Ҽ�
	        	if(e.getButton() == MouseEvent.BUTTON3) {//�Ҽ�����
	        		if(!inPicBounds(e.getX(),e.getY())) {
	        			return;
	        		}
	        		popupMenu.show(e.getComponent(), e.getX(), e.getY());
					popupMenu.show();
					commentX=(e.getX()-startX)*imgWidth/x;//ԭʼͼ�ϵ�λ��
					commentY=(e.getY()-startY)*imgHeight/y;
					//System.out.println("xy("+x+","+y+") e("+e.getX()+","+e.getY()+") start("+startX+","+startY+") img("+imgWidth+","+imgHeight+")");
					//System.out.println("commentXY("+commentX+","+commentY+")");
					//currComment.setPos((e.getX()-startX)*imgWidth/x, (e.getY()-startY)*imgHeight/y);
					//System.out.println("�Ҽ�����e.x,e.y="+e.getX()+","+e.getY());
					return;
				}
	        	//if((mods & InputEvent.BUTTON1_MASK)==0){//�����
	        	if(e.getButton() == MouseEvent.BUTTON2) {//�м����£�ʲôҲ����
	        		return;
	        	}
            	//System.out.println("���м�����");
	        	//�������
            	if(inPicBounds(e.getX(),e.getY()) && boundZoom) {//��ͼƬ�ϣ��ҿ�ѡ�Ŵ���Ч
            		//boundZoom=true;
            		boundX=e.getX()-startX;
            		boundY=e.getY()-startY;
            		return;
            	}
            	//return;
	          	//}
            	//�ǿ�ѡ�Ŵ�����£������ƶ�ͼƬ
	        	int tmpX, tmpY, maxX, maxY;
	        	tmpX=startX;
	        	tmpY=startY;
	        	if(startX<0){
	        		tmpX=0;
	        	}
	        	if(startY<0){
	        		tmpY=0;
	        	}
	        	//maxX=tmpX+x;
	        	//maxY=tmpY+y;
	        	if(inPicBounds(e.getX(),e.getY())){
	        		inPic = true;
	        		begin_x=e.getX();
	        		begin_y=e.getY();
	        	}else {
	        		inPic=false;
	        	}
	        }
	        public void mouseReleased(MouseEvent e) { 
	        	if(e.getButton() != MouseEvent.BUTTON1) {//������ͷţ�ʲôҲ����
	        		return;
	        	}
	        	
	        	if(boundZoom) {	//��ѡ�Ŵ���Чʱ���Կ�ѡ��Χ���зŴ�
	        		boundZoom=false;
	        		double zoomScale=1.0;
	        		//System.out.println("bW,bH="+boundWidth+","+boundHeight);
	        		if(boundWidth<0) {
	        			boundWidth=-boundWidth;
	        			boundX=boundX-boundWidth;
	        		}
	        		if(boundHeight<0) {
	        			boundHeight=-boundHeight;
	        			boundY=boundY-boundHeight;
	        		}
	        		if(boundWidth<=5 || boundHeight<=5) {
	        			boundWidth=0;
	        			boundHeight=0;
	        			return;
	        		}
	        		double boundScale=(double)boundWidth/boundHeight;
	        		double scrollpanelScale=(double)scrollpanel.getSize().width/scrollpanel.getSize().height;
					if(scrollpanelScale<boundScale) {
						zoomScale=(double)scrollpanel.getSize().width/boundWidth;
						x=(int)(zoomScale*x);
						y=(int)(x/scale);
						startX=(int)(-boundX*zoomScale);
						startY=(int)(-boundY*zoomScale+(scrollpanel.getSize().height-boundHeight*zoomScale)/2);
					}else {
						zoomScale=(double)scrollpanel.getSize().height/boundHeight;
						y=(int)(zoomScale*y);
						x=(int)(y*zoomScale);
						startY=(int)(-boundY*zoomScale);
						startX=(int)(-boundX*zoomScale+(scrollpanel.getSize().width-boundWidth*zoomScale)/2);
					}
					cgmLabel.setLocation(startX,startY);
					cgmLabel.setSize(x,y);
					floatPanel.setLocation(startX,startY);
					floatPanel.setSize(x,y);
					scrollpanel.repaint();
					repaint();
					boundWidth=0;
        			boundHeight=0;
	        	}else {
	        		if(inPic) {
	        			inPic=false;//��갴ť�ͷţ������϶�����
	        			//return;
	        		}
	        		//���϶��ƶ��������ǿ�ѡ�Ŵ��������������ǲ���ѡ����ĳ����ע
	        		if(showhideCommentbtn.isSelected()) {
	        			//int lastIndex=selectedAnnIndex;
	        			selectComment(e.getX()-startX,e.getY()-startY);
	        			//if(lastIndex!=selectedAnnIndex) {
	        				repaint();
	        			//}
	        		}else {
	        			selectedAnnIndex=-1;
	        		}
	        	}
	        }
			private void selectComment(int x, int y) {
				// TODO �Զ����ɵķ������
				selectedAnnIndex=-1;
				comments = floatPanel.getComments();
				if(comments==null || comments.size()<=0) {
					return;
				}
				for(int i=0;i<comments.size();i++) {
					
					if(x>=comments.get(i).getCurX() 
						&& x<=comments.get(i).getCurX()+comments.get(i).getCurW()
						&& y>=comments.get(i).getCurY()
						&& y<=comments.get(i).getCurY()+14) {
						selectedAnnIndex=i;
						break;
					}
				}
				floatPanel.setSelectedIndex(selectedAnnIndex);
				floatPanel.repaint();
				//System.out.println("selectedAnnIndex="+selectedAnnIndex);
			}
		});
		this.scrollpanel.addMouseMotionListener(new MouseAdapter() {
			public void mouseDragged(MouseEvent e)//����϶��¼���Ӧ
			{
				if(inPic) {
					startX -= (begin_x - e.getX());
					startY -= (begin_y - e.getY());
					begin_x = e.getX();
					begin_y = e.getY();
					cgmLabel.setLocation(startX,startY);
					//System.out.println("startX,StartY:"+startX+","+startY);
					floatPanel.setLocation(startX,startY);
					floatPanel.setSize(x,y);
					scrollpanel.repaint();
					return;
				}
				if(boundZoom && inPicBounds(e.getX(),e.getY())) {
					boundWidth=e.getX()-startX-boundX;
					boundHeight=e.getY()-startY-boundY;
					//Graphics g=floatPanel.getGraphics();
					if(floatpanelG==null) {
						floatpanelG=scrollpanel.getGraphics();
					}
					floatpanelG.setColor(Color.BLUE);
					int sX,sY,W,H;
					sX=startX+boundX;
					sY=startY+boundY;
					W=boundWidth;
					H=boundHeight;
					if(W<0) {
						W=-W;
						sX=sX-W;
					}
					if(H<0) {
						H=-H;
						sY=sY-H;
					}
					floatpanelG.drawRect(sX, sY, W, H);
					scrollpanel.repaint();
				}else {
					boundZoom=false;
				}
			}
		});
		this.scrollpanel.addMouseWheelListener(new MouseAdapter() {
			@Override
			public void mouseWheelMoved(MouseWheelEvent e) {
				// TODO �Զ����ɵķ������
				int tmpX, tmpY, maxX, maxY;
				int zoomStep=10;
				String tmpStr=getParameter("zoomstep");
				if(tmpStr!=null && "".equals(tmpStr.trim())) {
					zoomStep=Integer.valueOf(tmpStr);
				}
	        	tmpX=startX;
	        	tmpY=startY;
	        	if(startX<0){
	        		tmpX=0;
	        	}
	        	if(startY<0){
	        		tmpY=0;
	        	}
	        	maxX=tmpX+x;
	        	maxY=tmpY+y;
	        	if(inPicBounds(e.getX(),e.getY())){
	        		int mx,my;
	        		double xpos, ypos;
	        	    mx=e.getX();
	        	    my=e.getY();
	        	    xpos=(double)(mx-startX)/x;
	        	    ypos=(double)(my-startY)/y;
	        	    int direct=-1;//Ĭ������С
	        	    if(e.getWheelRotation()==-1){
	        	      direct=1;
	        	    }
	        	    if(direct==-1) {
	        	    	if(x<200 || y<200) {
	        	    		System.out.println("x,y="+x+","+y);
	        	    		return;
	        	    	}
	        	    }
	        	    x=x+zoomStep*direct;
	        	    y=y+(int)(zoomStep/scale*direct);
	        	    //startX -= 5*direct;
	        	    //startY -= (int)(5/scale*direct);
	        	    startX = mx-(int)(x*xpos);
	        	    startY = my-(int)(y*ypos);
	        	    cgmLabel.setLocation(startX, startY);
	        	    cgmLabel.setSize(x,y);
	        	    floatPanel.setLocation(startX,startY);
					floatPanel.setSize(x,y);
	        	    scrollpanel.repaint();
	        	}
			}
		});
		this.floatPanel.addKeyListener(new keyHandle());

		imageParam=getParameter("image");
		if(imageParam==null || "".equals(imageParam.trim())) {
			errorStr="image����Ϊ��\n";
		}else {
			openCgm();
		}
		System.err.println(errorStr);
		Dimension orgiDim=cgmLabel.getPreferredSize();
		imgWidth=orgiDim.width;
		imgHeight=orgiDim.height;
		scale=(double)imgWidth/orgiDim.height;
		this.floatPanel.setImgWidth(imgWidth);
		this.floatPanel.setImgHeight(imgHeight);
		
		x=getWidth();
		//System.out.println("imgWidth="+imgWidth+",x="+x);
		if(imgWidth<x) {
			x=imgWidth;
		}
		y=(int)(x/scale);
		startX=(int)((getWidth()-x)/2);
		startY=(int)((getHeight()-y)/2);
		if(startY<0) {
			startY=0;
		}
		//System.out.println("startX,startY="+startX+","+startY);
		//cgmLabel.setLocation(startX, startY);
		//cgmLabel.setPreferredSize(new Dimension(x,y));
		getComments();
		repaint();
		//setFocusable(true);
        //requestFocusInWindow();
	}
	class keyHandle extends KeyAdapter
	{

		public void keyTyped(KeyEvent e) {
				// TODO �Զ����ɵķ������
				//System.out.println("keycode="+e.getKeyCode());
				
				if(e.getKeyCode()==KeyEvent.VK_DELETE) {
					if(!showhideCommentbtn.isSelected()) {
						JOptionPane.showMessageDialog(null, "������ʾ��ע");
				        return;
					}
					if(comments==null || comments.size()<=0) {
						JOptionPane.showMessageDialog(null, "��ǰ��û���κα�ע");
				        return;
					}
					if(selectedAnnIndex<0) {
			        	JOptionPane.showMessageDialog(null, "����ѡ��Ҫɾ���ı�ע");
			        	return;
			        }
			        //floatPanel.setSelectedIndex(selectedAnnIndex);
			        if(JOptionPane.showConfirmDialog(null, "��ȷ��Ҫɾ���������ݵı�ע��\n"
			        		+comments.get(selectedAnnIndex).getComment())==JOptionPane.YES_OPTION) {
			        	comments.remove(selectedAnnIndex);
			        	floatPanel.setComments(comments);
			        	selectedAnnIndex=-1;
			        	floatPanel.setSelectedIndex(-1);
			        	repaint();
			        }
				}
			}
		
	}
	private boolean inPicBounds(int px,int py)
    {
        if(px >= startX && px <= startX + x &&
                            py >= startY && py <= startY+y)
            return true;
        else
            return false;
    }
	private void openCgm() {
		//System.out.println(getCodeBase()+imageParam);
		imageUrl=getCodeBase()+imageParam;
		try {
			cgmFileUrl = new URL(imageUrl);
			//System.out.println("cgmFileUrl="+cgmFileUrl);
			this.cgmLabel.open(cgmFileUrl);
			this.cgmLabel.repaint();
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			errorStr+="getUrl error:"+e.getMessage()+"\n";
			e.printStackTrace();
		}
	}
	private void buildUI() {
		this.setLayout(new BorderLayout(0,0));
		
		//ImageIcon icon=new ImageIcon("image/first_16x16.gif"," ");
		//btn1=new JButton(IconManager.getIcon("first_16x16.gif"));
		showAllbtn=new JButton(new ImageIcon(getImage(getCodeBase(),"image/showall.png")));
		showWidthbtn=new JButton(new ImageIcon(getImage(getCodeBase(),"image/showwidth.png")));
		show1v1btn=new JButton(new ImageIcon(getImage(getCodeBase(),"image/1v1.png")));
		showSelbtn=new JButton(new ImageIcon(getImage(getCodeBase(),"image/showsel.png")));
		showZoomOutbtn=new JButton(new ImageIcon(getImage(getCodeBase(),"image/zoomout.png")));
		showZoomInbtn=new JButton(new ImageIcon(getImage(getCodeBase(),"image/zoomin.png")));
		panbtn=new JButton(new ImageIcon(getImage(getCodeBase(),"image/pan.png")));
		showHotbtn=new JButton(new ImageIcon(getImage(getCodeBase(),"image/showhot.png")));
		showhideCommentbtn = new JCheckBox("��ʾ��ע");
		showhideCommentbtn.setBackground(new Color(220,220,220));
		
		showAllbtn.setPreferredSize(new Dimension(20, 20));
		showWidthbtn.setPreferredSize(new Dimension(20, 20));
		show1v1btn.setPreferredSize(new Dimension(20, 20));
		showSelbtn.setPreferredSize(new Dimension(20, 20));
		showZoomOutbtn.setPreferredSize(new Dimension(20, 20));
		showZoomInbtn.setPreferredSize(new Dimension(20, 20));
		panbtn.setPreferredSize(new Dimension(20, 20));
		showHotbtn.setPreferredSize(new Dimension(20, 20));
		
		topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT,2,5));
		topPanel.add(showAllbtn);
		topPanel.add(showWidthbtn);
		topPanel.add(show1v1btn);
		topPanel.add(showSelbtn);
		topPanel.add(showZoomOutbtn);
		topPanel.add(showZoomInbtn);
		topPanel.add(panbtn);
		//topPanel.add(showHotbtn);
		topPanel.add(showhideCommentbtn);
		
		JLabel tipLabel=new JLabel("[˵��]:���ǰ�����:�Ŵ���С;�����������϶�:�ƶ�/�Ŵ�ֲ�(�ȵ�ֲ��Ŵ�ť);����Ҽ��������鿴��ע�����ӱ�ע");
		//topPanel.add(tipLabel);
		
		topPanel.setBackground(new Color(220,220,220));
		
		this.add(topPanel,BorderLayout.NORTH);

		
		
		this.cgmLabel = new CGMPanel();
		this.cgmLabel.setBackground(Color.RED);
		
		floatPanel = new FloatPanel();
		
		scrollpanel=new JPanel();
		scrollpanel.setLayout(null);

		
		scrollpanel.add(floatPanel,new Integer(0));//new Integer(Integer.MAX_VALUE));
		scrollpanel.add(cgmLabel,new Integer(0));
		
		floatpanelG=floatPanel.getGraphics();
		
		this.add(scrollpanel,BorderLayout.CENTER);
		this.setVisible(true);
		//�����Ҽ������˵�
	    popupMenu=new JPopupMenu();         //ʵ���������˵�
	    menuItem=new JMenuItem("���ӱ�ע"); //��ʼ������
	    menuItem.addMouseListener(new MouseAdapter() {
	      @Override
	      public void mousePressed(MouseEvent e) {//���ӱ�ע�˵������Ӧ
	        super.mouseClicked(e);
	        //System.out.println("���ӱ�ע������");
	        //System.out.println("popupMenu.getX,e.getX="+popupMenu.getX()+","+e.getX());
	        //currComment.setPos((int)(popupMenu.getX()*imgWidth/x), (int)(popupMenu.getY()*imgHeight/y));
	        popupMenu.hide();
	        String rsStr=JOptionPane.showInputDialog("�������ע�ı�");
	        //System.out.println("rsStr="+rsStr);
	        if(rsStr!=null && !"".equals(rsStr.trim())) {
	        	Comment comment= new Comment();
	        	comment.setComment(rsStr);
	        	//currComment.setComment(rsStr);
	        	comment.setPos(commentX,commentY);
	        	comment.setCurH(x);
	        	comment.setCurW(y);
	        	comment.setPicH(imgWidth);
	        	comment.setPicW(imgHeight);
	        	if(comments==null) {
	        		comments=new ArrayList<Comment>();
	        	}
	        	//System.out.println("test...");
	        	comments.add(comment);
	        	floatPanel.setComments(comments);
	        	if(!showhideCommentbtn.isSelected()) {
	        		showhideCommentbtn.setSelected(true);
	        		System.out.println("selected..");
	        	}
	        	saveComments();
	        	showComment=true;
		        getComments();
		        cgmLabel.setLocation(startX, startY);
				floatPanel.setLocation(startX,startY);
				floatPanel.setSize(x,y);
		        repaint();
	        }
	      }
	    });
	    popupMenu.add(menuItem);
	    
	    showHideComment=new JMenuItem("��ʾ��ע");
	    showHideComment.addMouseListener(new MouseAdapter() {
	      @Override
	      public void mousePressed(MouseEvent e) {  //��ʾ���ر�ע�˵������Ӧ
	        super.mouseClicked(e);
	        //System.out.println("��ʾ��ע������");
	        showhideCommentbtn.setSelected(true);
	        showComment=true;
	        getComments();
	        cgmLabel.setLocation(startX, startY);
			floatPanel.setLocation(startX,startY);
			floatPanel.setSize(x,y);
	        repaint();
	      }
	    });
	    popupMenu.add(showHideComment);
	    
	    deleteCommentMenu=new JMenuItem("ɾ����ע");
	    deleteCommentMenu.addMouseListener(new MouseAdapter() {
	      @Override
	      public void mousePressed(MouseEvent e) {  //��ʾ���ر�ע�˵������Ӧ
	        super.mouseClicked(e);
	        if(!showhideCommentbtn.isSelected()) {
				JOptionPane.showMessageDialog(null, "������ʾ��ע");
		        return;
			}
			if(comments==null || comments.size()<=0) {
				JOptionPane.showMessageDialog(null, "��ǰ��û���κα�ע");
		        return;
			}
			if(selectedAnnIndex<0) {
	        	JOptionPane.showMessageDialog(null, "����ѡ��Ҫɾ���ı�ע");
	        	return;
	        }
	        //floatPanel.setSelectedIndex(selectedAnnIndex);
	        if(JOptionPane.showConfirmDialog(null, "��ȷ��Ҫɾ���������ݵı�ע��\n"
	        		+comments.get(selectedAnnIndex).getComment())==JOptionPane.YES_OPTION) {
	        	comments.remove(selectedAnnIndex);
	        	//floatPanel.setComments(comments);
	        	selectedAnnIndex=-1;
	        	floatPanel.setSelectedIndex(-1);
	        	repaint();
	        	saveComments();
	        }
	      }
	    });
	    popupMenu.add(deleteCommentMenu);
	}
	
	public void paint(Graphics g) {
		cgmLabel.setLocation(startX, startY);
		cgmLabel.setPreferredSize(new Dimension(x,y));
		floatPanel.setLocation(startX,startY);
		floatPanel.setPreferredSize(new Dimension(x,y));
		//floatPanel.bringToFront();
		topPanel.repaint();
		scrollpanel.repaint();
		//Graphics g1=floatPanel.getGraphics();
		showComment=showhideCommentbtn.isSelected();
		if(!showComment || comments==null || comments.size()<=0) {
			floatPanel.hide();
			return;
		}else {
			floatPanel.show();
			floatPanel.setComments(comments);
			floatPanel.repaint();
		}
		//repaint();
		//scrollpanel.repaint();
	}
	public void start() {

	}
	@Override
	public Object run() {
		// TODO �Զ����ɵķ������
		return null;
	}
	//�ַ���ת��ע  �ַ�����ʽΪ��x,y---comment;\n...
	private List<Comment> strToComments(String str) throws Exception {
		// TODO �Զ����ɵķ������
		List<Comment> rs=new ArrayList();
		if(str==null || "".equals(str.trim())) {
			return null;
		}
		//str=new String(str.getBytes("GBK"),"UTF8");
		//System.out.println("str="+str);
		String[] tmparr=str.split(";\n");
		for(int i=0;i<tmparr.length;i++) {
			String tmpstr=tmparr[i].trim();
			//System.out.println("tmpstr="+tmpstr);
			//tmpstr=new String(tmpstr.getBytes("GBK"),"UTF8");
			if(tmpstr.indexOf("---")<0) {
				continue;
			}
			//System.out.println("tmpstr="+tmpstr);
			Comment cmt=new Comment();
			int annX=Integer.valueOf(tmpstr.split("---")[0].split(",")[0]);
			//cmt.setX(annX);
			int annY=Integer.valueOf(tmpstr.split("---")[0].split(",")[1]);
			//cmt.setY(annY);
			tmpstr=tmpstr.substring(tmpstr.indexOf("---")+3);
			//System.out.println("x,y,ann="+annX+","+annY+","+tmpstr);
			cmt.setPos(annX,annY);
        	cmt.setCurH(x);
        	cmt.setCurW(y);
        	cmt.setPicH(imgWidth);
        	cmt.setPicW(imgHeight);
			cmt.setComment(tmpstr);
			rs.add(cmt);
		}
		return rs;
	}
	public void getComments(){
		try {
			URL annurl=new URL(getCodeBase()+getAnnotatePage+"?imgfile="+imageParam);
			URLConnection open = annurl.openConnection();
	        InputStream input = open.getInputStream();
	        byte[] bytes = new byte[input.available()];
	        //bytes = new byte[input.available()];
	        input.read(bytes);
	        String str = new String(bytes,"UTF-8");
	        //System.out.println("1 str="+str);
	        //System.out.println("2ISO8859-1 : str="+str);
	        //str=new String(str.getBytes("ISO-8859-1"),"GBK");
	        //System.out.println("iso8859-12gbk:"+str);
	        //str=new String(str.getBytes("GBK"),"UTF-8");
	        //System.out.println("gbk2utf-8:"+str);
	        //str = new String(bytes,"GBK");
	        comments=strToComments(str);
	        //floatPanel.setComments(comments);
		} catch (Exception e1) {
			// TODO �Զ����ɵ� catch ��
			e1.printStackTrace();
		}
	}
	public void saveComments() {
		comments=floatPanel.getComments();
		String str="";
		if(comments!=null) {
			for(int i=0;i<comments.size();i++) {
				str+=comments.get(i).getX()+","+comments.get(i).getY()+"---"+comments.get(i).getComment()+";\n";
			}
		}
		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        byte[] data = new byte[1024];
        int len = 0;

		try {
			URL url = new URL(getCodeBase()+setAnnotatePage);
			//System.out.println(getCodeBase()+setAnnotatePage);
	        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	        System.setProperty("sun.net.client.defaultConnectTimeout", "10000");
			System.setProperty("sun.net.client.defaultReadTimeout", "10000");

	        // ���ô��ݷ�ʽ
	        conn.setRequestMethod("POST");
	        //����
	        //conn.addRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
	        
	        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	        conn.setDoOutput(true);
	        conn.setDoInput(true);
	        // ���ò��û���
	        conn.setUseCaches(false);
	        //Ȩ��
	        //conn.setRequestProperty("Authorization", " Bearer fc58be57c46b32f9a2c32e5393684ac0");
	         // ��ʼ��������
	        conn.connect();
	        OutputStream  out = conn.getOutputStream();     
	        // д��������ַ���
	        //str=URLEncoder.encode(str);
	        out.write(("imgfile="+imageParam+"&").getBytes());
	        str="annotates="+str;
	        out.write(str.getBytes("UTF-8"));
	        out.flush();
	        out.close();
	        
	        // ���󷵻ص�״̬
	        if (conn.getResponseCode() == 200) {
	            //System.out.println("���ӳɹ�");
	            // ���󷵻ص�����
	            InputStream in = conn.getInputStream();
	            String a = null;

                byte[] data1 = new byte[in.available()];
                in.read(data1);
                in.close();
                // ת���ַ���
                a = new String(data1);
                a=a.trim();
                if(!a.equals("success")) {
                	System.out.println("a="+a);
                	JOptionPane.showMessageDialog(null, "���ݻ�ȡʧ��");
                }
	        } else {
	            System.out.println(conn.getResponseCode()+":no++");
	        }
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
}
